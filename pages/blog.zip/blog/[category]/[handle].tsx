import {
  builder,
  BuilderComponent,
  BuilderContent,
  useIsPreviewing,
} from "@builder.io/react";
import Head from "next/head";
import DefaultErrorPage from "next/error";
import React from 'react';
import { Link } from '@components/Link/Link'


builder.init("c782aff3c66f48acb425981b997feb10");

function BlogArticle({ article, articles }) {
  const isPreviewing = useIsPreviewing();
  console.log("Articles......", articles);
  if (!article && !isPreviewing) {
    return (
      <>
        <Head>
          <meta name="robots" content="noindex" />
        </Head>
        <DefaultErrorPage statusCode={404} />
      </>
    );
  }

  return (
    // Wrapping the structured data in BuilderContent allows
    // it to update in real time as your custom fields are edited in the
    // Visual Editor
    <BuilderContent
      content={article}
      options={{ includeRefs: true }}
      model="blog-article"
    >
      {(data, loading, fullContent) => ( !loading &&
        <React.Fragment>
          <Head>
            {/* Render meta tags from custom field */}
            <title>{data?.title}</title>
            <meta name="description" content={data?.blurb} />
            <meta name="og:image" content={data?.image} />
          </Head>

          <div>
            <div>{data?.title}</div>
            {/* Render the Builder drag/drop'd content */}
            <BuilderComponent
              name="blog-article"
              content={fullContent}
              options={{ includeRefs: true }}
            />
          </div>
          <h2>blog.....</h2>
          {articles?.map(item => (
            <div style={{display: "flex"}} key={item?.data.handle}>
            {/* <h2>{item?.data.category?.value?.data?.categoryName}</h2>
            <h3>{item?.data.handle}</h3> */}
            <Link href={`/blog/${item.data.category?.value?.data?.categoryName}/${item?.data.handle}`} >
                {item?.data?.title}
            </Link>
            </div>
          ))}
        </React.Fragment>
      )}
    </BuilderContent>
  );
}

export const search = (searchString) => builder.getAll('blog-article', {
  query: {
    '$or': [{
        'data.description': {
          $regex: `${searchString}`,
          $options: 'i'
        },
      },
      {
        'data.title': {
          $regex: `${searchString}`,
          $options: 'i'
        },
      },
    ]
  }
});

export async function getStaticProps({ params }) {

  console.log("Params....cat", params?.category)

  const article = await builder
    .get("blog-article", {
      // Include references, like our `author` ref
      options: { includeRefs: true },
      query: {
        // Get the specific article by handle
        "data.handle": params.handle,
      },
    })
    .promise() || null;

  const articles = await builder
    .getAll("blog-article", {
      // Include references, like our `author` ref
      options: { includeRefs: true },
    }) || null
  console.log("Length============", articles.length);    
  return {
    props: {
      article,
      articles
    },
  };
}

export async function getStaticPaths() {
  return {
    // Optionally, use builder.getAll() to fetch all paths,
    // or just allow fallback: true to render any path
    paths: [],
    fallback: true,
  };
}

export default BlogArticle;
